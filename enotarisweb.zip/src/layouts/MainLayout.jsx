// src/layouts/MainLayout.jsx
import { Outlet } from "react-router";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";

export default function MainLayout() {
  return (
    <div className="w-full min-h-screen bg-primary">
      <Navbar />
      <main className="">
        {/* Outlet adalah tempat halaman child ditampilkan */}
        <Outlet />
      </main>
      <Footer />
    </div>
  );
}
