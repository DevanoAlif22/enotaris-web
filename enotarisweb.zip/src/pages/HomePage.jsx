const HomePage = () => {
  return (
    <div>
      <div className="flex flex-col md:flex-row">
        <div className="flex-2 bg-blue-500 p-4 text-white">Kolom 1</div>
        <div className="flex-1 bg-green-500 p-4 text-white">Kolom 2</div>
        <div className="flex-1 bg-red-500 p-4 text-white">Kolom 3</div>
      </div>
    </div>
  );
};

export default HomePage;
