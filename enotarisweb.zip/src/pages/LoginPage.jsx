// src/pages/LoginPage.jsx
const LoginPage = () => {
  return (
    <>
      <h1 className="text-xl font-semibold mb-4">Login</h1>
      <form>
        <input
          type="text"
          placeholder="Username"
          className="border p-2 w-full mb-3"
        />
        <input
          type="password"
          placeholder="Password"
          className="border p-2 w-full mb-3"
        />
        <button className="bg-blue-500 text-white px-4 py-2 rounded">
          Login
        </button>
      </form>
    </>
  );
};

export default LoginPage;
