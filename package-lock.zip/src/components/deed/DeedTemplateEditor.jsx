// components/deed/DeedTemplateEditor.jsx
import { useEffect, useMemo, useRef, useState } from "react";
import ReactQuill from "react-quill-new";
import "react-quill-new/dist/quill.snow.css";
import { jsPDF } from "jspdf";
import html2canvas from "html2canvas";
import { buildTokenMap, replaceTokens } from "../../utils/project/deedTemplate";
import PagedPreview from "./PagedPreview";
import { templateService } from "../../services/templateService"; // ⬅️ NEW

export default function DeedTemplateEditor({
  activity,
  initialHtml,
  onSave,
  onExportPdf,
  saving = false,
  exporting = false,
}) {
  const MM_TO_PX = 96 / 25.4;
  const A4PX = { w: Math.round(210 * MM_TO_PX), h: Math.round(297 * MM_TO_PX) };

  const [template, setTemplate] = useState(() =>
    typeof initialHtml === "string" && initialHtml.trim()
      ? initialHtml
      : DEFAULT_TEMPLATE
  );

  // ⬇️ NEW: state untuk daftar & pilihan template
  const [tplItems, setTplItems] = useState([]); // [{id,label,html}]
  const [tplLoading, setTplLoading] = useState(false);
  const [selectedTplId, setSelectedTplId] = useState("");

  // Ambil daftar template saat mount
  useEffect(() => {
    (async () => {
      try {
        setTplLoading(true);
        const res = await templateService.list({ per_page: 100 });
        const items = Array.isArray(res?.data) ? res.data : [];
        setTplItems(
          items.map((it) => ({
            id: it.id,
            name: it.name,
            html: String(it.custom_value || ""),
          }))
        );
      } catch (e) {
        // boleh ganti ke toast mu
        console.error("Gagal load templates:", e?.message || e);
      } finally {
        setTplLoading(false);
      }
    })();
  }, []);

  // Kalau initialHtml berubah
  useEffect(() => {
    if (typeof initialHtml === "string") {
      setTemplate(initialHtml.trim() ? initialHtml : DEFAULT_TEMPLATE);
    } else if (initialHtml == null) {
      setTemplate(DEFAULT_TEMPLATE);
    }
  }, [initialHtml]);

  const tokenMap = useMemo(() => buildTokenMap(activity), [activity]);
  const html = useMemo(
    () => replaceTokens(template, tokenMap),
    [template, tokenMap]
  );

  const quillRef = useRef(null);

  // === Export PDF (pakai PagedPreview halaman per halaman) ===
  const handleExportPDFClient = async () => {
    const pageNodes = document.querySelectorAll(".paged-preview-page");
    if (!pageNodes.length) return;

    const pdf = new jsPDF({ unit: "px", format: [794, 1123], compress: true });

    for (let i = 0; i < pageNodes.length; i++) {
      const el = pageNodes[i];
      const clone = el.cloneNode(true);
      clone.style.cssText = `
        width: 794px; height: 1123px; padding: 40px; box-sizing: border-box;
        background:#fff; font-family:'Times New Roman', serif; font-size:12pt; line-height:1.6; color:#000;
        overflow:hidden; box-shadow:none; border-radius:0; margin:0; position:absolute; top:-10000px; left:-10000px;
      `;
      const pageNumber = clone.querySelector(".paged-preview-page-number");
      if (pageNumber) pageNumber.remove();

      document.body.appendChild(clone);
      try {
        const canvas = await html2canvas(clone, {
          backgroundColor: "#fff",
          scale: 2,
          width: 794,
          height: 1123,
          useCORS: true,
          allowTaint: true,
          logging: false,
        });
        const imgData = canvas.toDataURL("image/png", 1.0);
        if (i > 0) pdf.addPage([794, 1123]);
        pdf.addImage(imgData, "PNG", 0, 0, 794, 1123);
      } finally {
        document.body.removeChild(clone);
      }
    }
    pdf.save("akta.pdf");
  };

  const insertToken = (token) => {
    if (!quillRef.current) return;
    const quill = quillRef.current.getEditor();
    const range = quill.getSelection(true);
    const pos = range ? range.index : quill.getLength();
    const txt = `{${token}}`;
    quill.insertText(pos, txt, "user");
    quill.setSelection(pos + txt.length);
    quill.focus();
  };

  const resetTemplate = () => setTemplate(DEFAULT_TEMPLATE);

  // === NEW: gunakan template yang dipilih
  const useSelectedTemplate = async () => {
    if (!selectedTplId) return;
    try {
      const res = await templateService.get(selectedTplId);
      const html = String(res?.data?.custom_value || "");
      setTemplate(html || DEFAULT_TEMPLATE);
      // opsional: scroll ke atas editor
      quillRef.current?.getEditor()?.setSelection(0, 0);
    } catch (e) {
      console.error("Gagal memuat template:", e?.message || e);
      alert("Gagal memuat template terpilih.");
    }
  };

  // Quill toolbar
  const modules = {
    toolbar: [
      [{ header: [1, 2, 3, 4, 5, 6, false] }],
      ["bold", "italic", "underline", "strike"],
      [{ align: [] }],
      [{ list: "ordered" }, { list: "bullet" }],
      [{ indent: "-1" }, { indent: "+1" }],
      [{ size: ["small", false, "large", "huge"] }],
      [{ color: [] }, { background: [] }],
      ["clean"],
      ["link", "image"],
    ],
    clipboard: { matchVisual: false },
  };
  const formats = [
    "header",
    "font",
    "size",
    "bold",
    "italic",
    "underline",
    "strike",
    "blockquote",
    "list",
    "bullet",
    "indent",
    "link",
    "image",
    "video",
    "align",
    "color",
    "background",
  ];

  return (
    <div className="space-y-6">
      {/* Editor + Sidebar */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Editor */}
        <div className="lg:col-span-2">
          <div className="mb-2">
            <div className="text-sm font-medium mb-2">Template Akta</div>

            {/* === NEW: Template Picker === */}
            <div className="flex items-center gap-2">
              <select
                className="border rounded px-2 py-1 text-sm"
                value={selectedTplId}
                onChange={(e) => setSelectedTplId(e.target.value)}
                disabled={tplLoading}
                title="Pilih template tersimpan"
              >
                <option value="">
                  {tplLoading ? "Memuat…" : "— Pilih template —"}
                </option>
                {tplItems.map((t) => (
                  <option key={t.id} value={t.id}>
                    {`${t.name}`}
                  </option>
                ))}
              </select>
              <button
                type="button"
                onClick={useSelectedTemplate}
                disabled={!selectedTplId || tplLoading}
                className="px-3 py-1.5 rounded bg-gray-100 hover:bg-gray-200 text-sm"
              >
                Gunakan
              </button>
              <button
                type="button"
                onClick={resetTemplate}
                className="px-3 py-1.5 rounded bg-gray-100 hover:bg-gray-200 text-sm"
                title="Kembalikan ke template bawaan"
              >
                Reset Bawaan
              </button>
            </div>
          </div>

          <div className="border rounded quill-wrap">
            <ReactQuill
              ref={quillRef}
              theme="snow"
              value={template}
              onChange={setTemplate}
              modules={modules}
              formats={formats}
              className="deed-quill"
              placeholder="Tulis template akta di sini..."
            />
          </div>

          {/* Actions */}
          <div className="mt-16 flex flex-wrap gap-8 items-center">
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => onSave?.(template)}
                disabled={saving}
                className="px-3 py-2 rounded bg-emerald-600 hover:bg-emerald-700 text-white transition-colors disabled:opacity-60"
              >
                {saving ? "Menyimpan…" : "Simpan Draft"}
              </button>
            </div>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={handleExportPDFClient}
                className="px-3 py-2 rounded bg-gray-100 hover:bg-gray-200 transition-colors"
              >
                Export PDF (Client)
              </button>
              <button
                type="button"
                onClick={() => onExportPdf?.(template)}
                disabled={exporting}
                className="px-3 py-2 rounded bg-[#0256c4] hover:bg-blue-700 text-white transition-colors disabled:opacity-60"
              >
                {exporting ? "Mengekspor…" : "Generate & Upload (Server)"}
              </button>
            </div>
          </div>
        </div>

        {/* Token List */}
        <div>
          <div className="text-sm font-medium mb-2">Token Tersedia</div>
          <div className="border rounded p-3 bg-gray-50 max-h-[500px] overflow-auto">
            <div className="text-xs text-gray-600 mb-2">
              Klik token untuk menyisipkan ke editor
            </div>
            <TokenList tokenMap={tokenMap} onInsertToken={insertToken} />
          </div>
        </div>
      </div>

      {/* Preview */}
      <div>
        <div className="text-sm font-medium mb-2">Preview</div>
        <PagedPreview html={html} />
      </div>
    </div>
  );
}

function TokenList({ tokenMap, onInsertToken }) {
  const keys = Object.keys(tokenMap);
  if (!keys.length) return <div className="text-sm text-gray-500">-</div>;
  return (
    <div className="space-y-1">
      {keys.map((k) => (
        <div key={k} className="group">
          <button
            type="button"
            onClick={() => onInsertToken(k)}
            className="w-full text-left p-2 rounded hover:bg-blue-50 border border-transparent hover:border-blue-200 transition-colors"
          >
            <div className="flex justify-between items-start gap-2">
              <code className="text-xs font-mono text-blue-600 bg-blue-50 px-1 rounded">{`{${k}}`}</code>
              <span className="text-xs text-gray-500 truncate flex-1 text-right">
                {String(tokenMap[k]).substring(0, 20)}
                {String(tokenMap[k]).length > 20 && "..."}
              </span>
            </div>
          </button>
        </div>
      ))}
    </div>
  );
}

const DEFAULT_TEMPLATE = `
<div style="text-align:center;margin-bottom:12px">
  <h2 style="margin:0">AKTA OTENTIK</h2>
  <div style="font-size:12px">Nomor: {activity_code}</div>
</div>

<p>Pada hari ini, tanggal {today}, bertempat di {schedule_place}, saya {notaris_name}, Notaris, telah membacakan akta dengan judul <b>{deed_name}</b> terkait aktivitas <b>{activity_name}</b>.</p>

<h3>Para Penghadap</h3>
{parties_table}

<h3>Keterangan Penghadap</h3>
<p>Nama Penghadap Pertama: <b>{penghadap1_name}</b><br/>
NIK: {penghadap1_nik} — Alamat: {penghadap1_address}, {penghadap1_city}, {penghadap1_province}</p>

<h3>Kelengkapan Dokumen</h3>
<ul>
  <li>NIK (P1): {penghadap1_req_nik}</li>
  <li>Surat Kuasa (P1): {penghadap1_req_surat_kuasa}</li>
</ul>

<p>Jadwal pembacaan: {schedule_datetime} — Catatan: {schedule_note}</p>

<p style="margin-top:36px">Demikian akta ini dibuat, dibacakan dan ditandatangani sebagaimana mestinya.</p>
`;
