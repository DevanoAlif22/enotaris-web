"use client";
import { useEffect, useRef, useState } from "react";
import { Link, useParams, useNavigate } from "react-router-dom";
import ReactQuill from "react-quill-new";
import "react-quill-new/dist/quill.snow.css";

import { templateService } from "../../services/templateService";
import { showError, showSuccess } from "../../utils/toastConfig";
import PagedPreview from "../../components/deed/PagedPreview";

export default function TemplateEditorPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const templateId = id;

  const [name, setName] = useState("");
  const [customValue, setCustomValue] = useState(""); // ⬅️ ganti jadi custom_value
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  const quillRef = useRef(null);

  // ambil detail kalau edit
  useEffect(() => {
    if (!templateId) return;
    (async () => {
      try {
        setLoading(true);
        const res = await templateService.get(templateId);
        const tpl = res?.data;
        setName(tpl?.name || "");
        setCustomValue(tpl?.custom_value || "");
      } catch (e) {
        showError(e.message || "Gagal memuat template.");
      } finally {
        setLoading(false);
      }
    })();
  }, [templateId]);

  const handleSave = async () => {
    try {
      setSaving(true);
      if (templateId) {
        await templateService.update(templateId, {
          name,
          custom_value: customValue,
        });
        showSuccess("Template berhasil diperbarui.");
      } else {
        await templateService.create({ name, custom_value: customValue });
        showSuccess("Template berhasil dibuat.");
      }
      navigate("/app/template");
    } catch (e) {
      showError(e.message || "Gagal menyimpan template.");
    } finally {
      setSaving(false);
    }
  };
  const NBSP4 = "\u00A0\u00A0\u00A0\u00A0";
  // Quill toolbar
  const modules = {
    toolbar: [
      [{ header: [1, 2, 3, 4, 5, 6, false] }],
      ["bold", "italic", "underline", "strike"],
      [{ align: [] }],
      [{ list: "ordered" }, { list: "bullet" }],
      [{ indent: "-1" }, { indent: "+1" }],
      [{ size: ["small", false, "large", "huge"] }],
      [{ color: [] }, { background: [] }],
      ["clean"],
      ["link", "image"],
    ],
    clipboard: { matchVisual: false },
    keyboard: {
      bindings: {
        handleTab: {
          key: 9,
          handler: function (range) {
            const quill = quillRef.current?.getEditor();
            if (!quill) return true;
            quill.insertText(range.index, NBSP4, "user");
            quill.setSelection(range.index + NBSP4.length, 0, "user");
            return false;
          },
        },
        handleShiftTab: {
          key: 9,
          shiftKey: true,
          handler: function (range) {
            const quill = quillRef.current?.getEditor();
            if (!quill) return true;
            // hapus 4 NBSP jika tepat di belakang kursor
            const prev = quill.getText(Math.max(0, range.index - 4), 4);
            if (prev === NBSP4) {
              quill.deleteText(range.index - 4, 4, "user");
              quill.setSelection(range.index - 4, 0, "user");
              return false;
            }
            return true;
          },
        },
      },
    },
  };
  const formats = [
    "header",
    "font",
    "size",
    "bold",
    "italic",
    "underline",
    "strike",
    "blockquote",
    "list",
    "bullet",
    "indent",
    "link",
    "image",
    "video",
    "align",
    "color",
    "background",
  ];

  return (
    <div className="space-y-6 p-6">
      <h1 className="text-2xl font-semibold dark:text-white">
        {templateId ? "Edit Template" : "Tambah Template"}
      </h1>

      {loading ? (
        <div>Memuat…</div>
      ) : (
        <>
          {/* Form Input */}
          <div className="grid grid-cols-1 gap-6">
            <div className="lg:col-span-2">
              <div className="mb-4">
                <label className="block text-sm font-medium mb-1">
                  Nama Template
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full border rounded px-3 py-2"
                  placeholder="Contoh: Akta Pendirian CV"
                />
              </div>

              <div className="mb-2">
                <div className="text-sm font-medium mb-2">Isi Template</div>
                <div className="border rounded quill-wrap">
                  <ReactQuill
                    ref={quillRef}
                    theme="snow"
                    value={customValue}
                    onChange={setCustomValue}
                    modules={modules}
                    formats={formats}
                    className="deed-quill"
                    placeholder="Tulis isi template…"
                  />
                </div>
              </div>

              {/* Actions */}
              <div className="mt-8 flex flex-wrap gap-4 items-center">
                <button
                  type="button"
                  onClick={handleSave}
                  disabled={saving}
                  className="px-4 py-2 rounded bg-[#0256c4] hover:bg-blue-700 text-white font-semibold transition-colors disabled:opacity-60"
                >
                  {saving ? "Menyimpan…" : "Simpan"}
                </button>
                <Link
                  to="/app/template"
                  className="px-4 py-2 rounded bg-gray-200 hover:bg-gray-300 transition-colors"
                >
                  Batal
                </Link>
              </div>
            </div>
          </div>

          {/* Preview Section */}
          <div>
            <div className="text-sm font-medium mb-2">Preview</div>
            <PagedPreview html={customValue} />
          </div>
        </>
      )}
    </div>
  );
}
